//
//  CheckMatching.h
//  Lab02
//
//  Modified by Jeman Park on 2023/09/24.
//

#ifndef CHECKMATCHING_H
#define CHECKMATCHING_H

#include "StackType.h"

bool checkMatching(char string[], int length);


#endif /* CHECKMATCHING_H */
